package relacion1;

public class Relacion1 {

    public static void main(String[] args) {
        AccesoDatos ad = new AccesoDatos();
        Ventana v = new Ventana("Ejercicio 1 2 3 y 4", ad);
    }

}
